"""
Brett Bishop
1000425627
9/15/14
Task 1 for homework 3 is a program that will compute the value of the expression
x/2+x//2
part a) for all the integer values of x between 30 and 37
"""

i=30

while i<=37:
    x=i/2+i//2
    print(i,' /  2  + ',i,' //  2 = ',x)
    i=i+1
