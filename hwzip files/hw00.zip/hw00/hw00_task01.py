"""
Brett Bishop
ID 1000425627
Date : 8/26/14
Description: dummy assignment used to practice hw submission requirements.
"""
