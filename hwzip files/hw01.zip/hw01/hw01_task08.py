"""
Brett Bishop
UT ID 1000425627
9/1/14
This program will ask the user to enter two real numbers and compute and display
operations between the two: multiplication, division, integer division, modulo , exponentiation.
"""

n1=float(input("Enter n1: "))
n2=float(input("Enter n2: "))
print(n1,'*',n2,"=",n1*n2)
print(n1,'/',n2,"=",n1/n2)
print(n1,'//',n2,"=",n1//n2)
print(n1,'%',n2,"=",n1%n2)
print(n1,'**',n2,"=",n1**n2)
print(" ")
print(n2,'*',n1,"=",n2*n1)
print(n2,'/',n1,"=",n2/n1)
print(n2,'//',n1,"=",n2//n1)
print(n2,'%',n1,"=",n2%n1)
print(n2,'**',n1,"=",n2**n1)




