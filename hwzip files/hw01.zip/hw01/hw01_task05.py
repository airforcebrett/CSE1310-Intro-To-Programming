"""
Brett Bishop
UT ID 1000425627
9/1/14
This program will repeatedly print a cheer given by the user.
"""

cheer_1 = input("Enter the cheer: ")
repetitions = int(input("Enter the number of repetitions: "))
cheer_many = cheer_1 * repetitions
print(cheer_many)

#Needed to define the variable repititions as an integer.
