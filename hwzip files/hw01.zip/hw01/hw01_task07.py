"""
Brett Bishop
UT ID 1000425627
9/1/14
This program will ask the user to enter two nouns and a verb then print a sentence created using this data.
"""

n1=input("Enter the first noun: ")
n2=input("Enter the second noun: ")
v1=input("Enter a verb: ")
print('The',n1, v1,'over the',n2,'.')
