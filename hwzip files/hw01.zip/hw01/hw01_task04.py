"""
Brett Bishop
UT ID 1000425627
9/1/14
This program will compute the area of a rectangle.
"""



short_side = 10
long_side =  17
rectangle_area = short_side * long_side
print(rectangle_area)

# Needed to define short_side before he includes the variable in an expression.

